# The Voices

Four fragments of a fractured mind. They speak whether you want them to or not.

---

## LOGIC
*Cold analysis. Pattern recognition. The part that sees through lies but misses the heart.*



---

## INSTINCT
*Gut feelings. Danger sense. The part that keeps you alive but might make you cruel.*



---

## EMPATHY
*Reading others. Feeling what they won't say. The part that understands everyone but might paralyze you with their pain.*



---

## GHOST
*Memory. Trauma. The past that speaks. The part that reminds you who you were — whether you want to remember or not.*



---

*Style notes to follow. — Aria*
