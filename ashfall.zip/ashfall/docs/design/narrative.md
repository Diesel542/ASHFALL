# Narrative: The Five of Ashfall

Five people. Five reasons to stay. Five ways this ends.

---

## THE LEADER
*Or someone who thinks they are.*



---

## THE HEALER
*Or someone who used to be.*



---

## THE THREAT
*Or someone the settlement treats as one.*



---

## THE SECRET-KEEPER
*The one who knows what's underneath.*



---

## THE MIRROR
*The one who reflects your choices back at you.*



---

*Archetypes to start. Aria will make them bleed.*
